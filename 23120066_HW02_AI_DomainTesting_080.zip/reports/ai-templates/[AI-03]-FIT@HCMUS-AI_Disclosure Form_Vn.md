**Khoa Công nghệ Thông tin (FIT) – Trường Đại học Khoa học Tự nhiên (HCMUS)**

**CS423 / CSC15003 – Kiểm chứng Phần mềm (AI-augmented · 2026\)**

**CHÍNH SÁCH AI · BIỂU MẪU — 2026 v1.0**

# **Biểu mẫu Khai báo Sử dụng AI**

*Đính kèm cho mọi bài tập có dùng AI ở bất kỳ mức nào.*

*Tài liệu được biên soạn lại từ Med Kharbach, PhD (2026) — Mẫu Chính sách Sử dụng AI cho Giáo dục Đại học. Giấy phép CC BY-NC-SA 4.0. Phiên bản này được FIT@HCMUS điều chỉnh cho môn CS423 / CSC15003 Kiểm chứng Phần mềm.*

## **1\. Thông tin Môn học & Sinh viên**

| Mục | Giá trị |
| :---- | :---- |
| **Môn học:** | CS423 / CSC13003 – Kiểm chứng Phần mềm |
| **Mã bài tập:** | HW#02 |
| **Tên bài tập:** |  Domain Testing on EShop |
| **Cấp độ AI (1–5):** | Cấp 4 |
| **Ngày:** | 20/10/2026 |
| **Họ tên sinh viên:** | Võ Thiện Nhân |
| **MSSV:** | 23120066 |

## **2\. Câu hỏi Khai báo**

### **1\. Công cụ AI đã dùng:**

Github Copilot - GPT Luna 5.6

### **2\. Giai đoạn nào của bài tập có dùng AI:**

*Tick tất cả: [x] brainstorm  [x] outline  [x] viết nháp  [] phản hồi  [x] sửa chữa  [] code  [x] phân tích dữ liệu  [] thiết kế đồ hoạ  [] khác (ghi rõ).*

### **3\. Prompt / nhiệm vụ chính cho AI:**

*Dán nguyên văn 2–3 prompt quan trọng nhất. Để xem đầy đủ, đính kèm Phụ lục A (prompt\_log.md).*

```
/create-skill Tạo skill tên domain-testing
1. Skill làm gì:
Khi tôi đưa một yêu cầu/spec, phân tích các biến đầu vào và sinh test case theo kỹ thuật domain testing: phân vùng tương đương
(equivalence partitioning)
Với mỗi biến: xác định miền hợp lệ/không hợp lệ và các lớp tương đương, chưa cần phân tích giá trị biên

2. Đầu ra:
- Bảng biến: tên, kiểu dữ liệu, miền hợp lệ, miền không hợp lệ
- Bảng test case: ID, biến, lớp tương đương, giá trị test, kết quả mong đợi.
- Với nhiều biến: nêu cách kết hợp (mỗi lần chỉ thay một biến, hoặc pairwise).
- Xuất ra Markdown, (và Excel (.xlsx) nếu tôi yêu cầu).

3. Quy tắc riêng:
- Luôn ghi rõ giả định nếu spec thiếu giới hạn.
- Xử lý cả kiểu số, chuỗi (độ dài, ký tự đặc biệt, Unicode, tiếng Việt có dấu), ngày giờ, enum, và giá trị rỗng/null.
- Không bịa quy tắc nghiệp vụ; chỗ nào mơ hồ thì yêu cầu tôi xác nhận.

4. Ví dụ để test skill:
- "Trường tuổi nhận số nguyên từ 18 đến 60"
- "Mật khẩu 8-20 ký tự, phải có chữ hoa và số"
- "Số tiền chia hóa đơn, đơn vị VND, nguyên dương, tối đa 100 triệu"

Hãy hỏi tôi các điểm còn thiếu trước khi viết, rồi chạy thử các ví dụ trên.
```

```
/domain-testing tạo test case cho FR-03, xuất kết quả ra file .xlsx
```

### **4\. Phần cụ thể AI đóng góp:**

AI sinh các test cases trừ những test cases tôi bổ sung đã ghi trong phần Mandatory Disclosure của REPORT.md
AI không đóng góp vào các file thuộc ai_templates và phần AI Critique.

### **5\. Cách tôi rà soát / chỉnh sửa / xác minh đầu ra AI:**

Tôi xác minh các test cases do AI cung cấp bằng cách kiểm tra lại phân miền dữ liệu hợp lệ và không hợp lệ rồi kiểm tra các test cases trên các miền.
 
### **6\. Trích dẫn (nếu môn yêu cầu):**

## **3\. Cam đoan Trung thực**

*Bằng việc ký tên dưới đây, tôi cam đoan thông tin khai báo ở trên là chính xác và đầy đủ. Tôi hiểu rằng việc không khai báo hoặc khai báo sai lệch về việc dùng AI sẽ bị coi là vi phạm liêm chính học thuật và có thể dẫn đến điểm 0 cho bài tập cùng việc bị chuyển lên hội đồng kỷ luật.*

## **Chữ ký**

| Họ tên sinh viên (in hoa): | VÕ THIỆN NHÂN |
| :---- | :---- |
| **MSSV:** | 23120066 |
| **Lớp / Khoá:** | 23_3 |
| **Môn học:** | CS423 / CSC13003 – Kiểm chứng Phần mềm |
| **Giảng viên:** | Lâm Quang Vũ |
| **Ngày:** | 20/10/2026 |
| **Chữ ký:** | vothiennhan |

## **Tham khảo**

* Kharbach, M. (2026). AI Use Policy Templates for Higher Education. CC BY-NC-SA 4.0.  
* ISTQB Foundation Level Syllabus (latest version).  
* Hardman, P. (2025). A Post-AI Learning Taxonomy.  
* Fuster Rabella, M. (2025). OECD Education Working Paper No. 338\.  
* Perkins, M., Roe, J., & Furze, L. (2025). AI Assessment Scale.  
* Anthropic (2025). Building reliable AI test agents — engineering blog.  
* DeepEval & Promptfoo documentation — testing frameworks for LLM systems.